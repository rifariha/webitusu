<?php

/**
 * 
 *
 * @version $Id$
 * @copyright 2003 
 **/

class rhc_dashboard_calendar {

}
?>