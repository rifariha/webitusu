<?php

/**
 * 
 *
 * @version $Id$
 * @copyright 2003 
 **/

include 'tennisclub.php';

?>