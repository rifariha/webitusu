<?php

/**
 * 
 *
 * @version $Id$
 * @copyright 2003 
 **/

//metro pro is a Genesis child theme.
include 'genesis.php';
?>