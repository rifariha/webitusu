<html>
<head>
<link rel='stylesheet' id='twentytwelve-fonts-css'  href='spinner.css' type='text/css' media='all' />
</head>
<body style="background-color:black">

	<div class="xspinner xspinner--steps icon-xspinner" aria-hidden="true"></div>
	<div class="xspinner icon-xspinner-2" aria-hidden="true"></div>
	<div class="xspinner icon-xspinner-3" aria-hidden="true"></div>
	<div class="xspinner icon-xspinner-4" aria-hidden="true"></div>
	<div class="xspinner icon-xspinner-5" aria-hidden="true"></div>
	<div class="xspinner icon-xspinner-6" aria-hidden="true"></div>
	<div class="xspinner xspinner--steps2 icon-xspinner-7" aria-hidden="true"></div>



</body>
</html>
