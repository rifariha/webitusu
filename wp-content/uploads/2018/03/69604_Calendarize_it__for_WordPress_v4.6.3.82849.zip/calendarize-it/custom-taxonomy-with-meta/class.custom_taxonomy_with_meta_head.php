<?php

/**
 * 
 *
 * @version $Id$
 * @copyright 2003 
 * Author: Alberto Lau (Righthere.com)
 **/


class custom_taxonomy_with_meta_head {
	function __construct ($meta){
		  if(!is_array($meta)||empty($meta))return;
		  foreach($meta as $m){
		  
		  }
	}
}
 
?>