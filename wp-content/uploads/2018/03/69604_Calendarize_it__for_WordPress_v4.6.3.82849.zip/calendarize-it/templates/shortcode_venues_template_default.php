<div class="rhc-venue">
	<div class="rhc-venue-name">{name}</div>
	<div class="rhc-venue-description">{description}</div>
	<div class="rhc-venue-map">[venue_gmap address='{gaddress}' glat='{glat}' glon='{glon}' info_windows='{ginfo}']</div>
</div>
