<div class="rhc-sidelist-item">
	<div class="rhc-sidelist-image"></div>
	<div class="rhc-sidelist-body">
		<div class="rhc-sidelist-date">dddd MMMM d, yyyy</div>
		<div class="rhc-sidelist-title">title</div>	
	</div>
</div>